# Botni doimiy ishlaydigan qilib joylashtirish

Bot 24/7 ishlashi kerak — eslatmalar shu ishlab turgan program orqali yuboriladi.
Quyida eng oson yo'l ko'rsatilgan.

---

## 0-qadam. Tokenni yangilash (majburiy)

Eski token ochiq joyga tushgan, uni bekor qilish shart:

**@BotFather** → `/mybots` → botni tanlang → **API Token** →
**Revoke current token** → yangi tokenni saqlang.

---

## 1-qadam. Google Calendar ruxsati

Serverda brauzer yo'q, shuning uchun **xizmat akkaunti** (service account)
usulini tanlang — bu eng ishonchli yo'l.

1. [Google Cloud Console](https://console.cloud.google.com/) → yangi loyiha.
2. **APIs & Services → Library** → *Google Calendar API* → **Enable**.
3. **APIs & Services → Credentials → Create credentials → Service account**.
   Nom bering (masalan `ota-bot`), **Done** bosing.
4. Yaratilgan akkauntni bosing → **Keys → Add key → Create new key → JSON**.
   Yuklab olingan faylni `service_account.json` deb nomlang.
5. Shu sahifadan akkauntning **email manzilini** ko'chirib oling
   (`ota-bot@loyiha-nomi.iam.gserviceaccount.com` ko'rinishida).
6. Endi **otangizning Google Calendar**iga kiring:
   `Settings → Otangizning kalendari → Share with specific people` →
   yuqoridagi email'ni qo'shing → ruxsat darajasi:
   **"Make changes to events"** → **Send**.
7. `.env` faylida `CALENDAR_ID` ga otangizning pochtasini yozing
   (masalan `otam@gmail.com`).

> Shundan keyin bot hech qanday parol so'ramaydi va rejalar to'g'ridan-to'g'ri
> otangizning kalendariga tushadi.

---

## 2-qadam. Server olish

Eng arzon variantlar (oyiga ~$4–6):

| Xizmat | Izoh |
|---|---|
| Hetzner Cloud | eng arzon, CX22 tarifi yetadi |
| DigitalOcean | oddiy panel, $4 dan |
| Contabo / Vultr | shunga o'xshash |
| Oracle Cloud | bepul tarifi bor (ammo sozlashi murakkabroq) |

Ubuntu 24.04 tanlang. Server yaratilgandan keyin unga kiring:

```bash
ssh root@SERVER_IP
```

---

## 3-qadam. Variant A — Docker bilan (tavsiya etiladi)

```bash
# Docker o'rnatish
curl -fsSL https://get.docker.com | sh

# Papka yaratib, fayllarni ko'chiring
mkdir -p ~/ota-bot && cd ~/ota-bot
# (bot.py, gcal.py, requirements.txt, Dockerfile, docker-compose.yml,
#  service_account.json fayllarini shu papkaga yuklang)

# Sozlamalar
cp .env.example .env
nano .env          # BOT_TOKEN va CALENDAR_ID ni to'ldiring (OWNER_IDS tayyor)

# Ishga tushirish
docker compose up -d --build

# Loglarni ko'rish
docker compose logs -f
```

Bot endi doimiy ishlaydi va server qayta yuklansa ham o'zi yonadi.

Yangilash kerak bo'lsa:

```bash
docker compose up -d --build
```

---

## 4-qadam. Variant B — Docker'siz, systemd bilan

```bash
apt update && apt install -y python3-venv git
adduser --disabled-password --gecos "" ubuntu   # allaqachon bo'lsa o'tkazib yuboring
mkdir -p /home/ubuntu/ota-bot && cd /home/ubuntu/ota-bot
# fayllarni shu papkaga yuklang

python3 -m venv venv
./venv/bin/pip install -r requirements.txt

cp .env.example .env && nano .env
chown -R ubuntu:ubuntu /home/ubuntu/ota-bot
chmod 600 .env service_account.json

# xizmat sifatida ro'yxatga olish
cp ota-bot.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now ota-bot

# holatini ko'rish
systemctl status ota-bot
journalctl -u ota-bot -f
```

---

## 5-qadam. Tekshirish

1. Telegramda botga `/start` yuboring — salomlashishi kerak.
2. **➕ Yangi reja** → nomi → `ertaga 09:00` → `60` → sababi → **🟡 O'rta**.
3. Google Calendar'ni ochib ko'ring — reja sariq rangda turgan bo'lishi kerak.
4. Eslatmani sinash uchun hozirdan **17 daqiqa keyingi** vaqtga reja qo'shing
   va 2 daqiqa kutib turing — xabar kelishi kerak.

---

## Xavfsizlik

- `.env`, `service_account.json`, `token.json` fayllarini hech qachon
  GitHub'ga yuklamang (`.gitignore` shuning uchun qo'shilgan).
- Serverda ularga faqat o'zingiz kirishingiz uchun: `chmod 600`.
- `OWNER_IDS` allaqachon to'ldirilgan (206004279), begonalar botni ishlatolmaydi.
  Otangizning ID sini ham qo'shsangiz, vergul bilan yozing.

---

## Tez-tez uchraydigan xatolar

| Xato | Sababi va yechimi |
|---|---|
| `Unauthorized` | Token xato yoki bekor qilingan — `.env` dagi `BOT_TOKEN` ni tekshiring |
| `404 Not Found` (Calendar) | `CALENDAR_ID` xato, yoki kalendar xizmat akkauntiga share qilinmagan |
| `403 insufficientPermissions` | Share qilishda "Make changes to events" tanlanmagan |
| Eslatma kelmadi | Server vaqti boshqa mintaqada — `TZ=Asia/Tashkent` qo'yilganini tekshiring |
| Bot javob bermaydi | `docker compose logs -f` yoki `journalctl -u ota-bot -f` bilan logni ko'ring |
